package com.aecor.eurosports.model;

/**
 * Created by asoni on 05-02-2018.
 * asoni@aecordigital.com
 * Aecor Digital
 */

public class FinalPlacingModel {

    private String pos;
    private String team_name;
    private String team_flag;
    private String team_logo;

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getTeam_flag() {
        return team_flag;
    }

    public void setTeam_flag(String team_flag) {
        this.team_flag = team_flag;
    }

    public String getTeam_logo() {
        return team_logo;
    }

    public void setTeam_logo(String team_logo) {
        this.team_logo = team_logo;
    }
}
